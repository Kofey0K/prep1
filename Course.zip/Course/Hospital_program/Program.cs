﻿using System;
using Hospital_Lib;

namespace Hospital_program
{
    class Program
    {
        static void Main(string[] args)
        {
            Hospital.Run();
        }
    }
}
